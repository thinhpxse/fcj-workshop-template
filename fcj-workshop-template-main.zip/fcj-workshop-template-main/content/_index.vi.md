---
title: "Báo cáo thực tập"
date: "`r Sys.Date()`"
weight: 1
chapter: false
---

# Báo cáo thực tập
### Thông tin sinh viên:
&emsp; **Họ và tên:** Nguyễn Văn A

&emsp; **Số điện thoại:** 0989888999

&emsp; **Email:** Anguyenvan@gmail.com

&emsp; **Trường:** Đại học Sư phạm Kỹ thuật TP.HCM

&emsp; **Ngành:** Công nghệ thông tin

&emsp; **Lớp:** AWS082025

&emsp; **Công ty thực tập:** Công ty TNHH Amazon Web Services Vietnam

&emsp; **Vị trí thực tập:** FCJ Cloud Intern

&emsp; **Thời gian thực tập:** Từ ngày 12/08/2025 đến ngày 12/11/2025

![Ảnh đại diện của bạn](/images/avatar.png)



### Nội dung báo cáo

1.  [Worklog](1-Worklog/)
2.  [Proposal](2-Proposal/)
3.  [Các bài blogs đã dịch](3-BlogsTranslated/)
4.  [Các events đã tham gia](4-EventParticipated/)
5.  [Workshop](5-Workshop/)
6.  [Tự đánh giá](6-Self-evaluation/)
7.  [Chia sẻ, đóng góp ý kiến](7-Feedback/)